﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FE_StringAlign
{
    public partial class Form1 : Form
    {
        string ooutput = "";
        public Form1()
        {
            InitializeComponent();
            //(id,created,employee(id,firstname,employeeType(id), lastname),location)
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string iinput = tbInput.Text.Replace('(', '{').Replace(')', '}');
            iinput = iinput.Substring(1,iinput.Length-2);
            Align_recuresive("", iinput);
            lblOutput.Text = ooutput;
        }

        private string TransformToStringArray(string toSTrArray)
        {
            if(toSTrArray.Contains('{'))
            {
                string countOfcharsToremove = toSTrArray.Substring(toSTrArray.IndexOf('{') + 1, (toSTrArray.LastIndexOf('}') - toSTrArray.IndexOf('{')) - 1);
                toSTrArray = toSTrArray.Remove((toSTrArray.IndexOf('{')) + 1, countOfcharsToremove.Length);
                toSTrArray = toSTrArray.Replace(",", "$");
                toSTrArray = toSTrArray.Insert(toSTrArray.IndexOf('{') + 1, countOfcharsToremove);
            }
            return  toSTrArray ;
        }

        private void Align_recuresive(string prefix, string input)
        {
            input = TransformToStringArray(input);
           List<string> stringArray = input.Split('$').ToList();
            for( int i =0; i < stringArray.Count; i++)
            {
                if (stringArray[i].Contains('{'))
                {
                    string splittedSubstring = stringArray[i].Substring(0,stringArray[i].IndexOf('{'));
                    ooutput = ooutput + prefix + splittedSubstring + '\n';
                    string nextloopinput = stringArray[i].Substring(stringArray[i].IndexOf('{') + 1, (stringArray[i].LastIndexOf('}') - stringArray[i].IndexOf('{')) - 1); 
                    Align_recuresive(prefix + '-', nextloopinput);
                }                   
                else
                    ooutput = ooutput + prefix + stringArray[i] + '\n';
            }
        }

        //private void Align_recuresive(string prefix, string input)
        //{
        //    for(int i =0; i <= input.Length-1;i++)
        //    {
        //        if( input[i] == '(')
        //        {
        //            int inputLength = input.LastIndexOf(')') - i;
        //            Align_recuresive("-", input.Substring(i+1,inputLength));
        //        }
        //        else if (input[i] == ',')
        //        {
        //            ooutput = ooutput + '\n' + prefix;
        //        }
        //        else if (input[i] == ')')
        //        {
        //            //do nothing
        //        }
        //        else
        //        {
        //            ooutput = ooutput + input[i];
        //        }
        //    }
        //}
            //        //toSTrArray = toSTrArray.Replace(",","\",\"");
            //toSTrArray = toSTrArray.Replace("{", "{\"");
            //toSTrArray = toSTrArray.Replace("}", "\"}");

        //    string[] stringArray = new string[] { iii,kkk,ll,jj };
        //stringArray = stringArray.OrderBy(s => s.Name).ToArray();
        //"id","created","employee{id,firstname,employeeType{id},lastname}","location" 

            //StringBuilder sb = new StringBuilder(toSTrArray);
            //for( int i =0; i < sb.Length; i++)
            //{
            //    if(sb[i] == ',')
            //    {
            //        sb.Insert(i, "\",\"");
            //    }
            //    if(sb[i] == '{')
            //    {
            //        i = toSTrArray.LastIndexOf('}') -1 ;
            //    }
            //}

        //private void Align_recuresive(string input, int startIndex, int endingIndex) //excluding statr - end paranthesis.
        //{
        //    string inputPartial = input.Substring(startIndex,endingIndex);
        //    for (int i =0; i<=inputPartial.Length;i++)
        //    {
        //        if()
        //    }
        //}
        //  Align_recuresive("", "id", "created", "employee{id,firstname,employeeType{id}, lastname}", "location");
        // Align_recuresive("", tbInput.Text.Substring(1,tbInput.Text.Length-2));
    }
}
