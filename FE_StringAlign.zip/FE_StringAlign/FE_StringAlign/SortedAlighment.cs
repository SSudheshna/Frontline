﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FE_StringAlign
{
    public partial class SortedAlighment : Form
    {
        string ooutput = "";
        public SortedAlighment()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ooutput = "";
            if(tbInput.Text.Trim() == "")
            {
                lblOutput.Text = "empty output";
            }
            else
            {
                 string iinput = tbInput.Text.Replace('(', '{').Replace(')', '}');
                iinput = iinput.Substring(1, iinput.Length - 2);
                Align_recuresive("", iinput);
                lblOutput.Text = ooutput;
            }
               
        }

        //Modyfying input to needed Array format on each loop. 
        private string TransformToStringArray(string toSTrArray)
        {
            try
            {
                if (toSTrArray.Contains('{'))
                {
                    string countOfcharsToremove = toSTrArray.Substring(toSTrArray.IndexOf('{') + 1, (toSTrArray.LastIndexOf('}') - toSTrArray.IndexOf('{')) - 1);
                    toSTrArray = toSTrArray.Remove((toSTrArray.IndexOf('{')) + 1, countOfcharsToremove.Length);
                    toSTrArray = toSTrArray.Replace(",", "$");
                    toSTrArray = toSTrArray.Insert(toSTrArray.IndexOf('{') + 1, countOfcharsToremove);
                }              
            }
            catch (Exception ex)
            {
                lblOutput.Text = "Please enter a string in proper format. \n Each string should be seperated by comma. \n Every opening brace should be closed. \n String should start and end with braces.";
            }
            return toSTrArray;
        }

        //Recursive call - takes any input of given format.
        private void Align_recuresive(string prefix, string input)
        {
            try
            {
                input = TransformToStringArray(input);
                List<string> stringList = input.Split('$').ToList();
                stringList.Sort();
                for (int i = 0; i < stringList.Count; i++)
                {
                    if (stringList[i].Contains('{'))
                    {
                        string splittedSubstring = stringList[i].Substring(0, stringList[i].IndexOf('{'));
                        ooutput = ooutput + prefix + splittedSubstring + '\n';
                        string nextloopinput = stringList[i].Substring(stringList[i].IndexOf('{') + 1, (stringList[i].LastIndexOf('}') - stringList[i].IndexOf('{')) - 1);
                        Align_recuresive(prefix + '-', nextloopinput);  //RECURSIVE CALL
                    }
                    else
                        ooutput = ooutput + prefix + stringList[i] + '\n';
                }
            }
            catch(Exception ex)
            {
                lblOutput.Text = "Please enter a string in proper format. \n Each string should be seperated by comma. \n Every opening brace should be closed. \n String should start and end with braces.";
            }

        }

        private void tbInput_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
